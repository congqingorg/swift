//
//  EditNoteViewController.swift
//  CloudDemo
//
//  Created by Gabriel Theodoropoulos on 9/4/15.
// modified by congq  on 01/13/16
//  Copyright (c) 2015 Appcoda. All rights reserved.
//

import UIKit
import QuartzCore
import CloudKit

protocol EditNoteViewControllerDelegate {
    
    func didSaveNote(noteRecord: CKRecord, wasEditingNote: Bool)
}

class EditNoteViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    
    @IBOutlet weak var txtNoteTitle: UITextField!
    
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var btnSelectPhoto: UIButton!
    
    @IBOutlet weak var btnRemoveImage: UIButton!
    
    @IBOutlet weak var viewWait: UIView!
    
    var editedNoteRecord: CKRecord!

    var imageURL: NSURL!
    var delegate: EditNoteViewControllerDelegate!

    
    let documentsDirectoryPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
    
    let tempImageName = "temp_image.jpg"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        imageView.isHidden = true
        btnRemoveImage.isHidden = true
        viewWait.isHidden = true
        
        let swipeDownGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(EditNoteViewController.handleSwipeDownGestureRecognizer(_:)))
        swipeDownGestureRecognizer.direction = UISwipeGestureRecognizerDirection.down
        view.addGestureRecognizer(swipeDownGestureRecognizer)
        
        //更新数据
        if let editedNote = editedNoteRecord {
            txtNoteTitle.text = editedNote.value(forKey: "noteTitle") as? String
            textView.text = editedNote.value(forKey: "noteText") as! String
            let imageAsset: CKAsset = editedNote.value(forKey: "noteImage") as! CKAsset
            imageView.image = UIImage(contentsOfFile: imageAsset.fileURL.path)
            imageView.contentMode = UIViewContentMode.scaleAspectFit
            
            imageURL = imageAsset.fileURL as NSURL!
            
            imageView.isHidden = false
            btnRemoveImage.isHidden = false
            btnSelectPhoto.isHidden = true
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        textView.layer.cornerRadius = 10.0
        btnSelectPhoto.layer.cornerRadius = 5.0
        btnRemoveImage.layer.cornerRadius = btnRemoveImage.frame.size.width/2
        
        navigationItem.setHidesBackButton(true, animated: false)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
   
    
    // MARK: IBAction method implementation
    
    @IBAction func pickPhoto(_ sender: AnyObject) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.savedPhotosAlbum) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    @IBAction func unsetImage1(_ sender: Any) {
        imageView.image = nil
        imageView.isHidden = true
        btnRemoveImage.isHidden = true
        btnSelectPhoto.isHidden = false
        imageURL = nil
    }
    
    @IBAction func saveNote1(_ sender: Any) {
        var isEditingNote: Bool!
        if txtNoteTitle.text == "" || textView.text == "" {
            return
        }
        
        viewWait.isHidden = false
        view.bringSubview(toFront: viewWait)
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        var noteRecord: CKRecord!
        
        if let editedNote = editedNoteRecord {
            noteRecord = editedNote
            isEditingNote = true
        }
        else {
            let timestampAsString = String(format: "%f", NSDate.timeIntervalSinceReferenceDate)
            let timestampParts = timestampAsString.components(separatedBy: ".")
            
            let noteID = CKRecordID(recordName: timestampParts[0])
            let noteRecord = CKRecord(recordType: "Notes", recordID: noteID)
            isEditingNote = false
        }

        noteRecord.setObject(txtNoteTitle.text as CKRecordValue?, forKey: "noteTitle")
        noteRecord.setObject(textView.text as CKRecordValue?, forKey: "noteText")
        noteRecord.setObject(NSDate(), forKey: "noteEditedDate")
        
        //保存图片
        if let url = imageURL {
            let imageAsset = CKAsset(fileURL: url as URL)
            noteRecord.setObject(imageAsset, forKey: "noteImage")
        }
        else {
            let fileURL = Bundle.main.url(forResource: "no_image", withExtension: "png")
            let imageAsset = CKAsset(fileURL: fileURL!)
            noteRecord.setObject(imageAsset, forKey: "noteImage")
        }
        
        //使用默认容器，然后使用私人数据库
        let container = CKContainer.default()
        let privateDatabase = container.privateCloudDatabase
        
        privateDatabase.save(noteRecord, completionHandler: { (record, error) -> Void in
            if (error != nil) {
                print(error)
            }
            else{
                self.delegate.didSaveNote(noteRecord: noteRecord, wasEditingNote: isEditingNote)
           //     self.dismiss(animated: true, completion: nil)
                self.navigationController?.popViewController(animated: true)
            }
            OperationQueue.main.addOperation({ () -> Void in
                self.viewWait.isHidden = true
                self.navigationController?.setNavigationBarHidden(false, animated: true)
            })
        })
     }
    
    
    
  
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func dismiss(_ sender: Any) {
        if let url = imageURL {
            let fileManager = FileManager()
            if fileManager.fileExists(atPath: url.absoluteString!) {
                do{
                }catch { }
                
            }
        }
        
        navigationController?.popViewController(animated: true)
    }
    // MARK: Custom method implementation
    func handleSwipeDownGestureRecognizer(_ swipeGestureRecognizer: UISwipeGestureRecognizer) {
        txtNoteTitle.resignFirstResponder()
        textView.resignFirstResponder()
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]){
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage!
        let imageData = UIImageJPEGRepresentation(image!, 0.6)
        let compressedJPGImage = UIImage(data: imageData!)
        imageView.image  = compressedJPGImage
        imageView.contentMode = UIViewContentMode.scaleAspectFit
        let path = documentsDirectoryPath.appendingPathComponent(tempImageName)
        NSLog("path", path)
        imageURL = NSURL(fileURLWithPath: path)
        
        do{
            
            try imageData?.write(to: imageURL as URL)
        }catch { }
        
        imageView.isHidden = false
        btnRemoveImage.isHidden = false
        btnSelectPhoto.isHidden = true
        
        dismiss(animated: true, completion: nil)
        
        
        
    }
    
    
    
}
