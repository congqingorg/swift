//
//  ViewController.swift
//  CloudDemo
//
//  Created by Gabriel Theodoropoulos on 9/4/15.
// modified by congq  on 01/13/16

//  Copyright (c) 2015 Appcoda. All rights reserved.
//

import UIKit
import CloudKit

class ListNotesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,EditNoteViewControllerDelegate  {

    @IBOutlet weak var tblNotes: UITableView!
    var arrNotes: Array<CKRecord> = []
    var selectedNoteIndex: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
         fetchNotes()
        tblNotes.delegate = self
        tblNotes.dataSource = self
        tblNotes.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    func fetchNotes() {
        let container = CKContainer.default()
        let privateDatabase = container.privateCloudDatabase
        let predicate = NSPredicate(value: true)
        
        let query = CKQuery(recordType: "Notes", predicate: predicate)
        
        privateDatabase.perform(query, inZoneWith: nil) { (results, error) -> Void in
            if error != nil {
                print(error)
            }
            else {
                print(results)
                for result in results! {
                    self.arrNotes.append(result as! CKRecord)
                }
                
                OperationQueue.main.addOperation({ () -> Void in
                    self.tblNotes.reloadData()
                    self.tblNotes.isHidden = false
                })
            }
        }

        
    }
    

    
    
    // MARK: UITableView method implementation
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrNotes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "idCellNote", for: indexPath) 
        let noteRecord: CKRecord = arrNotes[indexPath.row]
        cell.textLabel?.text = noteRecord.value(forKey: "noteTitle") as? String
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM dd, yyyy, hh:mm"
        cell.detailTextLabel?.text = dateFormatter.string(from: (noteRecord.value(forKey: "noteEditedDate") as! NSDate) as Date)
        
        let imageAsset: CKAsset = noteRecord.value(forKey: "noteImage") as! CKAsset
        cell.imageView?.image = UIImage(contentsOfFile: imageAsset.fileURL.path)
        cell.imageView?.contentMode = UIViewContentMode.scaleAspectFit

        return cell
    
    }
   
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        selectedNoteIndex = indexPath.row
        performSegue(withIdentifier: "idSegueEditNote", sender: self)
        
    }
   func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete {
            let selectedRecordID = arrNotes[indexPath.row].recordID
            
            let container = CKContainer.default
            let privateDatabase = container().privateCloudDatabase
            
            privateDatabase.delete(withRecordID: selectedRecordID, completionHandler: { (recordID, error) -> Void in
                if error != nil {
                    print(error)
                }
                else {
                    OperationQueue.main.addOperation({ () -> Void in
                        self.arrNotes.remove(at: indexPath.row)
                        self.tblNotes.reloadData()
                    })
                }
            })
                  }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "idSegueEditNote" {
            let editNoteViewController = segue.destination as! EditNoteViewController
            editNoteViewController.delegate = self

            if let index = selectedNoteIndex {
                editNoteViewController.editedNoteRecord = arrNotes[index]
            }
        }
    }

    func didSaveNote(noteRecord: CKRecord, wasEditingNote: Bool) {
        if !wasEditingNote {
            arrNotes.append(noteRecord)
        }
        else {
            arrNotes.insert(noteRecord, at: selectedNoteIndex)
            arrNotes.remove(at: selectedNoteIndex + 1)
            selectedNoteIndex = nil
        }
        
        
        if tblNotes.isHidden {
            tblNotes.isHidden = false
        }
        
        tblNotes.reloadData()
        
    }
   
}

